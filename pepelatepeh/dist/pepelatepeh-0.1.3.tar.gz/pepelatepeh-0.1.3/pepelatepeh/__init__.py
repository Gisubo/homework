from .latex_table import latex_table,latex_image,latex_doc

__all__ = ["latex_table", "latex_image","latex_doc"]

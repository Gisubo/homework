from setuptools import setup, find_packages

setup(
    name="pepelatepeh",
    version="0.1.3",
    description="LaTeX-code-generator for tables and images ",
    author="Nikita Savkin",
    packages=find_packages(),
    python_requires=">=3.7",
)